# SanalLauncher Pro 0.2

Android Minecraft Java launcher arayüzü ve mod kataloğu başlangıç projesi.

## Dahil
- Minecraft sürüm profilleri
- Fabric / Forge / NeoForge / Quilt / Vanilla seçimi
- RAM ayarı
- Profil sistemi
- Mod arama ekranı
- Modrinth API üzerinden arama
- GitHub Actions ile otomatik debug APK üretimi

## APK üretimi
Android Studio ile açıp `app:assembleDebug` çalıştırılabilir.
Ayrıca GitHub Actions workflow'u eklenmiştir; depoya push ettikten sonra Actions bölümünden `Build APK` çalıştırıldığında APK artifact olarak çıkar.

## Önemli
Bu proje Minecraft'ın kendisini veya Microsoft hesabı sistemini içermez. Gerçek Java oyun çalıştırma katmanı, mobil Java runtime, renderer, sürüm dosyası indirme ve resmi Microsoft oturumu ayrıca entegre edilmelidir.

Android'de Java Edition launcher teknolojisinin nasıl çalıştığına örnek olarak PojavLauncher/halefi projeleri incelenebilir. PojavLauncher kaynakları Java Edition'ı Android'de çalıştırmak ve Fabric/Forge desteği sağlamak için kapsamlı bir altyapı içerir.
