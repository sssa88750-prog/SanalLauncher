package com.sanalsali.sanallauncher

data class GameProfile(
    val name: String,
    val minecraftVersion: String,
    val loader: String,
    val memoryMb: Int = 2048
)

data class ModResult(
    val title: String,
    val slug: String,
    val description: String
)
