package com.sanalsali.sanallauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SanalLauncherApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanalLauncherApp() {
    var tab by remember { mutableIntStateOf(0) }
    var version by remember { mutableStateOf("1.21.1") }
    var loader by remember { mutableStateOf("Fabric") }
    var profile by remember { mutableStateOf("Survival") }
    var ram by remember { mutableIntStateOf(2048) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ModResult>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("SanalLauncher Pro") }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = {}, label = { Text("Oyna") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = {}, label = { Text("Modlar") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = {}, label = { Text("Profiller") })
                    NavigationBarItem(tab == 3, { tab = 3 }, icon = {}, label = { Text("Ayarlar") })
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
                when (tab) {
                    0 -> PlayScreen(version, loader, ram, { version = it }, { loader = it }, { ram = it })
                    1 -> ModsScreen(query, { query = it }, results, loading) {
                        loading = true
                        scope.launch {
                            results = withContext(Dispatchers.IO) {
                                try { ModrinthApi.search(query, version, loader.lowercase()) } catch (_: Exception) { emptyList() }
                            }
                            loading = false
                        }
                    }
                    2 -> ProfilesScreen(profile) { profile = it }
                    else -> SettingsScreen(ram) { ram = it }
                }
            }
        }
    }
}

@Composable
fun PlayScreen(version: String, loader: String, ram: Int,
               setVersion: (String)->Unit, setLoader: (String)->Unit, setRam: (Int)->Unit) {
    Text("Minecraft Java Edition", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(16.dp))
    Text("Minecraft sürümü")
    Dropdown(version, listOf("1.21.1","1.21","1.20.6","1.20.4","1.20.1","1.19.4","1.18.2","1.16.5","1.12.2"), setVersion)
    Spacer(Modifier.height(12.dp))
    Text("Mod loader")
    Dropdown(loader, listOf("Fabric","Forge","NeoForge","Quilt","Vanilla"), setLoader)
    Spacer(Modifier.height(12.dp))
    Text("RAM: ${ram} MB")
    Slider(ram.toFloat(), { setRam(it.toInt()) }, valueRange = 1024f..6144f, steps = 9)
    Spacer(Modifier.height(12.dp))
    Button(onClick = {}) { Text("Başlat") }
    Spacer(Modifier.height(8.dp))
    Text("Not: Oyun motoru ve Microsoft oturumu bu projeye ayrıca bağlanmalıdır.")
}

@Composable
fun ModsScreen(query: String, setQuery: (String)->Unit, results: List<ModResult>,
               loading: Boolean, search: ()->Unit) {
    Text("Mod Merkezi", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(query, setQuery, Modifier.fillMaxWidth(), label = { Text("Mod ara") })
    Spacer(Modifier.height(8.dp))
    Button(onClick = search) { Text(if (loading) "Aranıyor..." else "Modları Ara") }
    Spacer(Modifier.height(8.dp))
    LazyColumn {
        items(results) { mod ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(mod.title, style = MaterialTheme.typography.titleMedium)
                    Text(mod.description)
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {}) { Text("İndir") }
                }
            }
        }
    }
}

@Composable
fun ProfilesScreen(profile: String, setProfile: (String)->Unit) {
    Text("Profiller", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    listOf("Survival", "Modlu Survival", "Vanilla Test").forEach {
        Button(onClick = { setProfile(it) }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text(if (it == profile) "✓ $it" else it)
        }
    }
}

@Composable
fun SettingsScreen(ram: Int, setRam: (Int)->Unit) {
    Text("Ayarlar", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Text("RAM: $ram MB")
    Slider(ram.toFloat(), { setRam(it.toInt()) }, valueRange = 1024f..6144f, steps = 9)
    Text("Java Runtime, oyun klasörü, kontrol düzeni ve renderer seçenekleri burada bağlanacak.")
}

@Composable
fun Dropdown(value: String, options: List<String>, onSelect: (String)->Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(value) }
        DropdownMenu(open, { open = false }) {
            options.forEach {
                DropdownMenuItem(text = { Text(it) }, onClick = { onSelect(it); open = false })
            }
        }
    }
}
