package com.sanalsali.sanallauncher

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

object ModrinthApi {
    private const val BASE = "https://api.modrinth.com/v2/search"

    fun search(query: String, gameVersion: String, loader: String): List<ModResult> {
        if (query.isBlank()) return emptyList()
        val facets = "[[\"project_type:mod\"],[\"versions:$gameVersion\"],[\"categories:$loader\"]]"
        val url = BASE +
            "?query=" + URLEncoder.encode(query, "UTF-8") +
            "&facets=" + URLEncoder.encode(facets, "UTF-8") +
            "&limit=20"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        return try {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val hits = JSONArray(org.json.JSONObject(body).getJSONArray("hits").toString())
            buildList {
                for (i in 0 until hits.length()) {
                    val x = hits.getJSONObject(i)
                    add(ModResult(
                        x.optString("title"),
                        x.optString("slug"),
                        x.optString("description")
                    ))
                }
            }
        } finally {
            conn.disconnect()
        }
    }
}
